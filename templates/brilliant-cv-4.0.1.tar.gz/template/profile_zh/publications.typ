// Imports
#import "@preview/brilliant-cv:4.0.1": cv-publication, cv-section


#cv-section("学术著作")

#cv-publication(
  bib: bibliography("../assets/publications.bib"),
  key-list: (
    "smith2020",
    "jones2021",
    "wilson2022",
  ),
  ref-style: "apa",
)
