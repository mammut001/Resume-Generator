// Imports
#import "@preview/brilliant-cv:4.0.1": cv-honor, cv-section


#cv-section("Certificates")

#cv-honor(
  date: [2022],
  title: [AWS Certified Security],
  issuer: [Amazon Web Services (AWS)],
)

#cv-honor(
  date: [2017],
  title: [Applied Data Science with Python],
  issuer: [Coursera],
)

#cv-honor(
  date: [],
  title: [Bases de données et requêtes SQL],
  issuer: [OpenClassrooms],
)
