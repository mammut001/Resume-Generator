// Imports
#import "@preview/brilliant-cv:4.0.1": cv-section, cv-skill, h-bar


#cv-section("Compétences")

#cv-skill(
  type: [Langues],
  info: [Anglais #h-bar() Français #h-bar() Chinois],
)

#cv-skill(
  type: [Tech Stack],
  info: [Tableau #h-bar() Python (Pandas/Numpy) #h-bar() PostgreSQL],
)

#cv-skill(
  type: [Centres d'intérêt],
  info: [Natation #h-bar() Cuisine #h-bar() Lecture],
)
